---
title: FLUX.1 Open Ghibli Studio LoRA
emoji: 🖼
colorFrom: purple
colorTo: red
sdk: gradio
sdk_version: 5.14.0
app_file: app.py
pinned: false
short_description: AI web app that transforms photos into Ghibli-style artwork
models:
  - openfree/flux-chatgpt-ghibli-lora
---
